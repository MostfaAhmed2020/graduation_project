from fastapi import FastAPI, File, UploadFile
from fastapi.responses import JSONResponse
from transformers import pipeline
import uvicorn
import torchaudio
import tempfile

app = FastAPI()

# Load ASR model once on startup
asr = pipeline("automatic-speech-recognition", model="distil-whisper/distil-small.en")

@app.post("/transcribe")
async def transcribe_audio(file: UploadFile = File(...)):
    try:
        # Save uploaded file temporarily
        with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as tmp:
            contents = await file.read()
            tmp.write(contents)
            tmp_path = tmp.name

        # Load the audio with torchaudio
        speech_array, sampling_rate = torchaudio.load(tmp_path)

        # Perform transcription
        result = asr(speech_array[0].numpy(), sampling_rate=sampling_rate)
        return JSONResponse(content={"text": result["text"]})

    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})
